<?php

include ('config.php');

$id = $_GET['id_pelajar'];

$result = mysqli_query($con,"DELETE FROM maklumat where id_pelajar = '$id'");

echo"<script>alert('Maklumat berjaya dihapuskan')";

//sila lengkapkan kod aturacara

header("Location:index.php");

?>





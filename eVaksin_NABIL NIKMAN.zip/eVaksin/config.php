<!--Membuat sambungan ke db-->
<?php

$con=mysqli_connect("localhost","root","","vaksin") or die ("Failed");
//sila lengkapkan kod aturcara

?>

